/*
 * @copyright 2008-2013 Christoph Martens
 * @author Christoph Martens (martensms)
 * @website www.martens.ms
 * All rights reserved.
 */

#ifndef _JPG_H
#define _JPG_H

#define JPG_THRES_MAX	0x25
#define JPG_THRES_LOW	0x04
#define JPG_THRES_MIN	0x03

void init_JPEG_handler(char *parameters);

int preserve_jpg(bitmap *, int);

void write_JPEG_file (FILE *outfile, image *image);
image *read_JPEG_file (FILE *infile);

void bitmap_from_jpg(bitmap *bitmap, image *image, int flags);
void bitmap_to_jpg(image *image, bitmap *bitmap, int flags);

bitmap *compress_JPEG(image *image);

extern handler jpg_handler;

#define JPEG_READING	0
#define JPEG_WRITING	1

#endif /* _JPG_H */

