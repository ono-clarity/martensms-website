/*
 * @copyright 2008-2013 Christoph Martens
 * @author Christoph Martens (martensms)
 * @website www.martens.ms
 * All rights reserved.
 */

#ifndef _ITERATOR_H
#define _ITERATOR_H
#define INIT_SKIPMOD	32
#define DEFAULT_ITER	256

/* Slowly fade skip out at the end of the picture */
#define SKIPADJ(x,y)	((y) > (x)/32 ? 2 : 2 - ((x/32) - (y))/(float)(x/32))

/*
 * The generic iterator
 */

typedef struct _iterator {
	struct arc4_stream as;
	u_int32_t skipmod;
	int off;		/* Current bit position */
} iterator;

struct _bitmap;

void iterator_init(iterator *, struct _bitmap *,  u_char *key, u_int klen);
int iterator_next(iterator *, struct _bitmap *);

#define ITERATOR_CURRENT(x)	(x)->off

void iterator_seed(iterator *, struct _bitmap *, u_int16_t);
void iterator_adapt(iterator *, struct _bitmap *, int);

#endif
